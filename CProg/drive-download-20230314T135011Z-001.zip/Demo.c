    #include<stdio.h>

    void Display()
    {
        printf("Jay Ganesh...\n");
    }

    int main()                              
    {
        printf("Inside main.\n");

        Display();  // Function Call

        return 0;
    } 