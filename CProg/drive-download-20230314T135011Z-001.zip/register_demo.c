#include<stdio.h>

int main()
{
    auto int A = 10;
    register int B = 10;
    register int C;

    return 0;
}